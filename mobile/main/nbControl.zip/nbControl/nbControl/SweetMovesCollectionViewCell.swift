//
//  SweetMoveCollectionViewCell.swift
//  nbControl
//
//  Created by Cory Alini on 12/4/16.
//  Copyright © 2016 gis.coryalini. All rights reserved.
//

import UIKit

class SweetMovesCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var SweetMovesImage: UIImageView!
    @IBOutlet weak var SweetMovesLabel: UILabel!
    
}
