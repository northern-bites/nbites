//
//  HardwareBrain.swift
//  nbControl
//
//  Created by Cory Alini on 11/15/16.
//  Copyright © 2016 gis.coryalini. All rights reserved.
//

import Foundation

class hardwareBrain {
    
   
    var issues: Dictionary = [String:String]()
    
        
        
    
        
        
}
